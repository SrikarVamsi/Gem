const DEFAULT_API = 'http://127.0.0.1:8080';

async function getApiBase() {
  const { apiBase } = await chrome.storage.sync.get({ apiBase: DEFAULT_API });
  return apiBase || DEFAULT_API;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'factcheck-selection',
    title: 'Verify with FactCheck MCP',
    contexts: ['selection']
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'factcheck-selection') return;
  const apiBase = await getApiBase();
  const content = info.selectionText || '';
  try {
    const res = await fetch(`${apiBase}/check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content })
    });
    const data = await res.json();
    // send result to content script to render overlay
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'FACTCHECK_RESULT', data });
    }
  } catch (e) {
    console.error('FactCheck error', e);
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'FACTCHECK_ERROR', error: String(e) });
    }
  }
});
