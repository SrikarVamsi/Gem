function ensureContainer() {
  let el = document.getElementById('factcheck-mcp-overlay');
  if (!el) {
    el = document.createElement('div');
    el.id = 'factcheck-mcp-overlay';
    el.style.position = 'fixed';
    el.style.right = '16px';
    el.style.bottom = '16px';
    el.style.zIndex = '2147483647';
    el.style.maxWidth = '360px';
    el.style.fontFamily = 'system-ui, Arial, sans-serif';
    el.style.background = 'white';
    el.style.border = '1px solid #ddd';
    el.style.borderRadius = '8px';
    el.style.boxShadow = '0 4px 20px rgba(0,0,0,0.2)';
    el.style.padding = '12px';
    el.style.color = '#111';
    el.style.display = 'none';
    document.body.appendChild(el);
  }
  return el;
}

function verdictBadge(label) {
  const colors = {
    'Verified': '#16a34a',
    'Suspicious': '#d97706',
    'Fake': '#dc2626'
  };
  const color = colors[label] || '#2563eb';
  return `<span style="display:inline-block;padding:2px 8px;border-radius:999px;background:${color};color:white;font-weight:600;font-size:12px">${label}</span>`;
}

function renderResult(result) {
  const el = ensureContainer();
  const analysis = result?.analysis || {};
  const label = analysis?.label || 'Unknown';
  const explanation = analysis?.explanation || 'No explanation available';
  const evidence = analysis?.evidence || [];
  const scam = result?.scam?.is_suspicious ? '<div style="margin-top:6px;color:#b91c1c">⚠ Possible scam indicators detected.</div>' : '';

  const sourcesHtml = evidence.slice(0, 3).map(e => {
    const url = e?.url || '#';
    const quote = e?.quote || '';
    const support = e?.support || '';
    return `<div style="margin-top:6px;font-size:12px"><div style="color:#374151">${quote}</div><a href="${url}" target="_blank" style="color:#2563eb">Source</a> <span style="color:#6b7280">(${support})</span></div>`;
  }).join('');

  el.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <div style="font-weight:700">FactCheck</div>
      <button id="factcheck-close" style="border:none;background:transparent;font-size:16px;cursor:pointer">✕</button>
    </div>
    <div style="margin-bottom:8px">${verdictBadge(label)}</div>
    <div style="font-size:13px;line-height:1.4">${explanation}</div>
    ${scam}
    <div style="margin-top:8px;border-top:1px solid #eee;padding-top:8px">
      <div style="font-weight:600;font-size:12px;color:#374151">Evidence</div>
      ${sourcesHtml || '<div style="font-size:12px;color:#6b7280">No evidence extracted.</div>'}
    </div>
  `;

  el.style.display = 'block';
  el.querySelector('#factcheck-close')?.addEventListener('click', () => {
    el.style.display = 'none';
  });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'FACTCHECK_RESULT') {
    renderResult(msg.data);
  } else if (msg?.type === 'FACTCHECK_ERROR') {
    const el = ensureContainer();
    el.innerHTML = `<div style="font-weight:700;margin-bottom:8px">FactCheck</div><div style="color:#b91c1c">${msg.error}</div>`;
    el.style.display = 'block';
  }
});
