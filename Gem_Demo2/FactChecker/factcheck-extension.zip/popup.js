async function getApiBase() {
  const DEFAULT_API = 'http://127.0.0.1:8080';
  const { apiBase } = await chrome.storage.sync.get({ apiBase: DEFAULT_API });
  return apiBase || DEFAULT_API;
}

async function getSelection() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return '';
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => window.getSelection()?.toString() || ''
  });
  return result || '';
}

async function callApi(content) {
  const apiBase = await getApiBase();
  const res = await fetch(`${apiBase}/check`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content })
  });
  return res.json();
}

const input = document.getElementById('input');
const statusEl = document.getElementById('status');

document.getElementById('useSelection').addEventListener('click', async () => {
  input.value = 'Fetching selection...';
  const txt = await getSelection();
  input.value = txt || '';
});

document.getElementById('verify').addEventListener('click', async () => {
  const content = input.value.trim();
  if (!content) {
    statusEl.textContent = 'Please enter or select some text.';
    return;
  }
  statusEl.textContent = 'Verifying...';
  try {
    const data = await callApi(content);
    const label = data?.analysis?.label || 'Unknown';
    const expl = data?.analysis?.explanation || '';
    statusEl.textContent = `Result: ${label} — ${expl.slice(0,120)}`;
    // Also show overlay on page
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: 'FACTCHECK_RESULT', data });
  } catch (e) {
    statusEl.textContent = `Error: ${String(e)}`;
  }
});
